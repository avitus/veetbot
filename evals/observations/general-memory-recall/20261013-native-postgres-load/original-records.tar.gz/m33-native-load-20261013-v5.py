"""Native CPU encoding, leased indexing and cold/warm recall on synthetic PostgreSQL load.

The actual local adapter encodes every stored original through SemanticIndexingPass.
The intended historical-indexing configuration stores each current and historical
vector; exact row-count checks require both versions for every seeded original.
Every cold sample includes actual query preparation and both recall entry points.
These repeated synthetic load records do not establish answer-quality or independent
scenario evidence. Model reading and formation are measured by the separate capped
confirmation. No remote model/provider calls are made by this measurement.
"""

import argparse
import asyncio
import hashlib
import json
import platform
from dataclasses import replace
from decimal import Decimal
import os
import resource
import subprocess
from datetime import timedelta
from math import ceil
from pathlib import Path
from time import perf_counter
from typing import Any

from sqlalchemy import text

from agent_core.adapters.persistence.semantic_memory import PostgresSemanticMemoryIndex
from agent_core.adapters.persistence.sqlalchemy_models import MemoryRow, MemoryRevisionRow, ReconsolidationChangeRow
from agent_core.domain.memory import BeliefType, RecallQuery, RecallResult, Sensitivity
from agent_core.domain.local_embeddings import LocalEmbeddingConfig, LOCAL_EMBEDDING_REVISION
from agent_core.domain.semantic_work import EmbeddingConfig
from agent_core.memory.semantic_indexing import SemanticIndexingPass
from agent_core.memory.semantic_queries import SemanticQueryPreparation, SemanticQueryContext
from agent_core.evals.general_recall_composition import build, fixed_clock, system_clock, local_embedding_provider
from agent_core.evals.general_recall_database import evaluation_database
from agent_core.memory.reconsolidation_evidence import implementation_digest
from agent_core.memory.retrieval import DeterministicQueryFormer, HybridMemoryRetriever
from agent_core.tools.memory_search import MemorySearchTool
from tests.contract.memory_fixtures import memory
from tests.contract.support import NOW, SESSION_ID, principal, run, session, tool_context
from tests.integration.disposable_database import clone_recall_database
from tests.integration.m2_support import database_settings

TEXT = "copper sentinel deployment approval"


class MeasuredRetriever(HybridMemoryRetriever):
    observed: RecallResult | None = None

    async def recall(self, query: RecallQuery, **kwargs: Any) -> RecallResult:
        self.observed = await super().recall(query, **kwargs)
        return self.observed


async def collect(output: Path, root: Path, assets: Path, configuration: Path) -> None:
    if output.exists():
        raise ValueError("Retain existing measurements; choose a new output")
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
    local = LocalEmbeddingConfig.model_validate_json(configuration.read_text())
    embedding = EmbeddingConfig(space=local.space, usd_per_million_tokens=Decimal(0),
        pricing_revision='local-cpu@1', egress_revision=LOCAL_EMBEDDING_REVISION,
        residency_provider='local', request_usd=Decimal('0.01'), daily_usd=Decimal('0.10'),
        historical_indexing=True)
    digest = implementation_digest(root)
    report: dict[str, Any] = {
        "version": "recall-native-postgres-load@1",
        "activation_evidence": False,
        "registered_at": system_clock().now().isoformat(),
        "implementation_sha256": digest,
        "build_ref": subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
        "local_configuration": local.model_dump(mode='json'),
        "embedding_configuration": embedding.model_dump(mode='json'),
        "cpu_count": os.cpu_count(),
        "registered_loads": [100,1000,10000,100000],
        "registered_repeats_per_path_channel_temperature": 10,
        "sample_timeout_seconds": 30,
        "index_timeout_seconds": 21600,
        "index_measurements": [],
        "measurement_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "system": platform.platform(),
        "cpu": platform.processor(),
        "vector_dimensions": 384,
        "provider_calls": 0,
        "state": "registered",
        "measurements": [],
        "limitations": __doc__,
    }
    output.write_text(json.dumps(report, indent=2) + "\n")
    started = perf_counter()
    provider = local_embedding_provider(assets, local)
    try:
        async with clone_recall_database() as url:
            settings = replace(database_settings(), database_url=url)
            async with (
                evaluation_database(settings, storage="postgres", authorized=True),
                build(
                    settings=settings,
                    storage="postgres",
                    principal=principal(),
                    clock=fixed_clock(NOW),
                    enabled_tools=["memory.search"],
                    enabled_skills=[],
                ) as app,
            ):
                original = memory(statement="Copper sentinel is the deployment approval phrase.")
                original = original.model_copy(
                    update={
                        "belief_type": BeliefType.FACT,
                        "subject": "deployment approval",
                        "valid_from": NOW - timedelta(days=14),
                        "created_at": NOW - timedelta(days=14),
                        "updated_at": NOW - timedelta(days=14),
                    }
                )
                noise = memory(
                    belief_id=503, statement="The project review recorded a deployment note."
                ).model_copy(
                    update={
                        "belief_type": BeliefType.FACT,
                        "subject": "routine review",
                        "store_position": 2,
                    }
                )
                async with app.uow_factory() as uow:
                    await uow.sessions.create(session())
                    await uow.runs.create(run())
                    for record in (original, noise):
                        await uow.memories.upsert_belief(record)
                    assert isinstance(uow.semantic_memory, PostgresSemanticMemoryIndex)
                    db = uow.semantic_memory._session
                    report["postgres"] = await db.scalar(text("SELECT version()"))
                    report["pgvector"] = await db.scalar(
                        text("SELECT extversion FROM pg_extension WHERE extname = 'vector'")
                    )
                previous = 1
                for competing in (100, 1000, 10000, 100000):
                    setup = perf_counter()
                    async with app.uow_factory() as uow:
                        assert isinstance(uow.semantic_memory, PostgresSemanticMemoryIndex)
                        db = uow.semantic_memory._session
                        values = []
                        for column in MemoryRow.__table__.columns:
                            values.append(
                                "md5('recall-load:' || n::text)::uuid"
                                if column.name == "id"
                                else "n + 2"
                                if column.name in {"creation_sequence", "store_position"}
                                else f'm."{column.name}"'
                            )
                        columns = ", ".join(f'"{c.name}"' for c in MemoryRow.__table__.columns)
                        await db.execute(
                            text(
                                f"INSERT INTO memories ({columns}) SELECT {', '.join(values)} "
                                "FROM memories m CROSS JOIN generate_series("
                                "CAST(:first AS bigint), CAST(:last AS bigint)) n "
                                "WHERE m.id = :template"
                            ),
                            {"first": previous, "last": competing - 1, "template": noise.id},
                        )
                        # The bulk synthetic fixture retains the same owner inventory and
                        # source journal that ordinary upsert_belief writes. No vectors are
                        # inserted here; every vector must come from the native worker.
                        for table, omit_id in ((MemoryRevisionRow,True),(ReconsolidationChangeRow,False)):
                            cols=[c.name for c in table.__table__.columns if not (omit_id and c.name=='id')]
                            vals=[]
                            for col in cols:
                                if col=='belief_id': vals.append("md5('recall-load:' || n::text)::uuid")
                                elif col in {'sequence','creation_sequence'}: vals.append('n + 2')
                                elif col=='payload':
                                    vals.append("v.payload || jsonb_build_object('id', md5('recall-load:' || n::text)::uuid::text, 'store_position', n + 2)")
                                else: vals.append('v."'+col+'"')
                            await db.execute(text('INSERT INTO '+table.__tablename__+' ('+', '.join('"'+c+'"' for c in cols)+') SELECT '+', '.join(vals)+
                                ' FROM '+table.__tablename__+' v CROSS JOIN generate_series(CAST(:first AS bigint), CAST(:last AS bigint)) n WHERE v.belief_id = :template'),
                                {'first':previous,'last':competing-1,'template':noise.id})
                        await db.execute(text('UPDATE reconsolidation_owners SET creation_count=:size, change_count=:size WHERE tenant_id=:tenant AND principal_id=:owner'),
                            {'size':competing+1,'tenant':principal().tenant_id,'owner':principal().principal_id})
                        assert await db.scalar(text("SELECT count(*) FROM memories")) == competing + 1
                        await db.execute(text("ANALYZE memories"))
                        await db.execute(text("ANALYZE memory_vectors"))
                    previous = competing
                    setup_seconds = perf_counter() - setup
                    indexed_started = perf_counter()
                    slices, indexed = 0, 0
                    worker = SemanticIndexingPass(app.uow_factory,app.clock,principal(),provider,
                        embedding,admitted=lambda:True,local=local)
                    async with asyncio.timeout(21600):
                        while True:
                            part = await worker.run_slice()
                            if part.reason == 'not_due': break
                            if part.reason not in {'indexed','scanned'}:
                                raise RuntimeError('Indexing stopped: '+part.reason)
                            slices += 1; indexed += part.indexed
                            if slices % 100 == 0:
                                print(json.dumps({'load':competing,'index_slices':slices,'indexed':indexed}),flush=True)
                    async with app.uow_factory() as uow:
                        db=uow.semantic_memory._session
                        actual=await db.scalar(text('SELECT count(*) FROM memory_vectors'))
                        assert actual == 2 * (competing + 1), (actual,competing)
                        await db.execute(text('ANALYZE memory_vectors'))
                    report['index_measurements'].append({'competing_records':competing,
                        'indexed':indexed,'slices':slices,'elapsed_seconds':perf_counter()-indexed_started,
                        'maximum_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
                    output.write_text(json.dumps(report,indent=2)+'\n')
                    for channel in ("sparse", "dense", "hybrid"):
                        profile = app.memory_profiles.retrieval.model_copy(
                            update={
                                "semantic_enabled": channel != "sparse",
                                "semantic_channel": "dense" if channel == "dense" else "hybrid",
                                "reranking": "relevance",
                            }
                        )
                        lookup = SemanticQueryPreparation(app.uow_factory,app.clock,principal(),provider,
                            embedding,admitted=lambda:True,local=local,
                            context=lambda:SemanticQueryContext(policy_version='m33-load@1',
                                retrieval_policy=channel+'@1',surface_id='private',
                                task_sha256=hashlib.sha256(TEXT.encode()).hexdigest(),
                                sensitivity_floor=Sensitivity.RESTRICTED))
                        retriever = MeasuredRetriever(
                            app.uow_factory,
                            app.clock,
                            app.ids,
                            principal(),
                            profile=profile,
                            semantic_queries=lookup if channel != "sparse" else None,
                            reranking_admitted=lambda: True,
                        )
                        tool = MemorySearchTool(retriever, model_planning=True)
                        query = DeterministicQueryFormer(
                            principal(), current_scope="project-a"
                        ).from_text(TEXT)[0]
                        for path in ("automatic", "deliberate"):
                            samples = []
                            for repeat in range(20):
                                temperature='cold' if repeat % 2 == 0 else 'warm'
                                actual_query=query if path=='automatic' else tool.query(
                                    {'text':TEXT,'scope':'project-a','type_hints':['preference']},
                                    tenant_id=principal().tenant_id,principal_id=principal().principal_id)
                                if temperature=='cold': lookup.invalidate()
                                before = perf_counter()
                                async with asyncio.timeout(30):
                                    if channel != 'sparse':
                                        prepared=await lookup.prepare([actual_query])
                                        assert prepared.prepared == 1 or prepared.reason == 'cached', prepared
                                    if path == "automatic":
                                        result = await retriever.recall(
                                            query, session_id=SESSION_ID
                                        )
                                    else:
                                        called = await tool.execute(
                                            {
                                                "text": TEXT,
                                                "scope": "project-a",
                                                "type_hints": ["preference"],
                                            },
                                            tool_context(),
                                        )
                                        assert called.ok and retriever.observed is not None
                                        result = retriever.observed
                                elapsed_ms = (perf_counter() - before) * 1000
                                assert result.stages is not None
                                ranked = result.stages.ranked_ids
                                returned = [item.belief_id for item in result.items]
                                samples.append(
                                    {
                                        "repeat": repeat,
                                        "temperature": temperature,
                                        "elapsed_ms": elapsed_ms,
                                        "candidate_count": len(result.stages.candidate_ids),
                                        "target_rank": ranked.index(original.id) + 1
                                        if original.id in ranked
                                        else None,
                                        "target_rendered": original.id in returned,
                                        "tokens": result.tokens,
                                        "items": len(returned),
                                    }
                                )
                            times = sorted(row["elapsed_ms"] for row in samples)
                            row = {
                                "competing_records": competing,
                                "channel": channel,
                                "path": path,
                                "bulk_fixture_seconds": setup_seconds,
                                "p50_ms": times[ceil(len(times) * 0.5) - 1],
                                "p95_ms": times[ceil(len(times) * 0.95) - 1],
                                "samples": samples,
                            }
                            report["measurements"].append(row)
                            output.write_text(json.dumps(report, indent=2) + "\n")
                            print(
                                json.dumps({k: v for k, v in row.items() if k != "samples"}),
                                flush=True,
                            )
        assert not subprocess.check_output(["git","status","--porcelain"],cwd=root)
        assert implementation_digest(root) == digest, "Implementation changed during measurement"
        report["state"] = "completed"
    except BaseException as error:
        report.update(state="failed", error_class=type(error).__name__)
        raise
    finally:
        await provider.close()
        report["wall_seconds"] = perf_counter() - started
        report["finished_at"] = system_clock().now().isoformat()
        output.write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument('--root',required=True,type=Path)
    parser.add_argument('--assets',required=True,type=Path)
    parser.add_argument('--configuration',required=True,type=Path)
    args = parser.parse_args()
    asyncio.run(collect(args.output,args.root,args.assets,args.configuration))
